var searchData=
[
  ['io_5fport_5fread_5fcycles',['IO_PORT_READ_CYCLES',['../_d_a_p__config_8c.html#a28609612f80eb7b680e9a295ded2f3c0',1,'IO_PORT_READ_CYCLES():&#160;DAP_config.c'],['../_d_a_p__config_8h.html#a28609612f80eb7b680e9a295ded2f3c0',1,'IO_PORT_READ_CYCLES():&#160;DAP_config.h']]],
  ['io_5fport_5fwrite_5fcycles',['IO_PORT_WRITE_CYCLES',['../_d_a_p__config_8c.html#a119c70409a24e3a8bb35df07dffeb8c8',1,'IO_PORT_WRITE_CYCLES():&#160;DAP_config.c'],['../_d_a_p__config_8h.html#a119c70409a24e3a8bb35df07dffeb8c8',1,'IO_PORT_WRITE_CYCLES():&#160;DAP_config.h']]]
];
