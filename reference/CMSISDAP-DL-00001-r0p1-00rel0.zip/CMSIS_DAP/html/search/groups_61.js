var searchData=
[
  ['adapt_20vendor_20commands',['Adapt Vendor Commands',['../group___d_a_p___vendor___adapt__gr.html',1,'']]]
];
