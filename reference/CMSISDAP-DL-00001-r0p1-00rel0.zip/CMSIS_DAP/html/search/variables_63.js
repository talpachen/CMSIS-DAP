var searchData=
[
  ['connectiondescription',['connectionDescription',['../struct_r_d_d_i___d_a_p___c_o_n_n___d_e_t_a_i_l_s.html#a6debf7d2ffa3a661c5289e5e1b760855',1,'RDDI_DAP_CONN_DETAILS']]]
];
