var annotated =
[
    [ "RDDI_DAP_CONN_DETAILS", "struct_r_d_d_i___d_a_p___c_o_n_n___d_e_t_a_i_l_s.html", "struct_r_d_d_i___d_a_p___c_o_n_n___d_e_t_a_i_l_s" ]
];