var group___d_a_p___commands__gr =
[
    [ "General Commands", "group___d_a_p__gen_commands__gr.html", "group___d_a_p__gen_commands__gr" ],
    [ "Common SWD/JTAG Commands", "group___d_a_p__swj__gr.html", "group___d_a_p__swj__gr" ],
    [ "SWD Commands", "group___d_a_p__swd__gr.html", "group___d_a_p__swd__gr" ],
    [ "JTAG Commands", "group___d_a_p__jtag__gr.html", "group___d_a_p__jtag__gr" ],
    [ "Transfer Commands", "group___d_a_p__transfer__gr.html", "group___d_a_p__transfer__gr" ],
    [ "Response Status", "group___d_a_p___reponses___status.html", null ]
];