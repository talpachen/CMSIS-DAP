var group___d_a_p___vendor__gr =
[
    [ "Adapt Vendor Commands", "group___d_a_p___vendor___adapt__gr.html", "group___d_a_p___vendor___adapt__gr" ]
];