var group___d_a_p___config___hardware__gr =
[
    [ "CPU_CLOCK", "group___d_a_p___config___hardware__gr.html#ga512016e5f1966a8fd45b3f1a81ba5b8f", null ],
    [ "IO_PORT_WRITE_CYCLES", "group___d_a_p___config___hardware__gr.html#ga119c70409a24e3a8bb35df07dffeb8c8", null ]
];