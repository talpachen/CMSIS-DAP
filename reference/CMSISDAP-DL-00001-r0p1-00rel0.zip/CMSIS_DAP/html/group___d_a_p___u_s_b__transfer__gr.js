var group___d_a_p___u_s_b__transfer__gr =
[
    [ "DAP_TransferConfigure", "group___d_a_p__transfer__configure.html", null ],
    [ "DAP_Transfer", "group___d_a_p__transfer.html", null ],
    [ "DAP_TransferBlock", "group___d_a_p__transfer__block.html", null ],
    [ "DAP_TransferAbort", "group___d_a_p__transfer__abort.html", null ]
];